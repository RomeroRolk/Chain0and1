package cepochka;

import java.io.*;

public class InOut {

    static int max;

    public void in() {
        try (FileReader reader = new FileReader("input.txt")) {
            int c;
            int j = 0;
            while ((c = reader.read()) != -1) {
                String d = Character.toString((char) c);
                int x = Integer.parseInt(d);
                if (x == 1) {
                    j++;
                    if (j > max) {
                        max = j;
                    }
                } else {
                    j = 0;
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void out(String s) {
        try (FileWriter writer = new FileWriter("output.txt")) {
            writer.write(s);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
