
package cepochka;

public class Cepochka {
    public static void main(String[] args) {
        InOut rrr = new InOut();
        rrr.in();
        String s =Integer.toString(InOut.max);
        rrr.out(s);
    }
    
}
